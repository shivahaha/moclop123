﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SampleProject.Biz;
using SampleProject.Commons;
using SampleProject.Entity;

using System.Data;

namespace SampleProject.UserControls.TrustDistrict
{
    public partial class Details : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (!IsPostBack)
            {

                TrustRegionBiz trustRegionBiz = new TrustRegionBiz();
                DataTable trustRegion = trustRegionBiz.GetAllWithOutQuery1();

                ddTrustRegion.DataSource = trustRegion;
                ddTrustRegion.DataValueField = "TrustRegionId";
                ddTrustRegion.DataTextField = "TrustRegionName";
                ddTrustRegion.DataBind();

                string id = this.Request.QueryString["id"];
                int userId = Convert.ToInt32(id);
                TrustDistrictBiz trustDistrictBiz = new TrustDistrictBiz();
                TrustDistrictsEntity T = trustDistrictBiz.GetById(userId);
                if (string.IsNullOrEmpty(id))
                {
                }
                else
                {
                    txtTrustDistrictName.Text = T.TrustDistrictName.ToString();
                    txtDescription.Text = T.Description.ToString();
                    ddTrustRegion.SelectedValue = T.TrustRegionId.ToString();
                  
                }

            }
      
        }
    }
}