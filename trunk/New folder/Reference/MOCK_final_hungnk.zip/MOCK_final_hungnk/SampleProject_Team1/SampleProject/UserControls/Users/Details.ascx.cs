﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SampleProject.Biz;
using SampleProject.Commons;
using SampleProject.Entity;
using System.Data;
namespace SampleProject.UserControls.Users
{
    public partial class Details : System.Web.UI.UserControl
    {        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                RoleBiz roleBiz = new RoleBiz();
                DataTable Role = roleBiz.GetAllWithOutQuery1();

                drdRole.DataSource = Role;
                drdRole.DataValueField = "RoleId";
                drdRole.DataTextField = "RoleName";
                drdRole.DataBind();

                string id = this.Request.QueryString["id"];
                int userId = Convert.ToInt32(id);
                UserBiz user = new UserBiz();
                UserEntity T = user.GetById(userId);
                if (!string.IsNullOrEmpty(id))               
                {


                    txtUserName.Text = T.UserName.ToString();
                    txtPassword.Text = T.Password.ToString();
                    txtEmail.Text = T.Email.ToString();
                    drdRole.SelectedValue = T.RoleId.ToString();
                    drdRole.Text = T.RoleName.ToString();
                    chkIsActive.Checked = T.IsActive;
                }

            }
        
        }

        /// <summary>
        /// Insert or Update User
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Submit_Click(object sender, EventArgs e)
        {
            string id = this.Request.QueryString["id"];            
            bool isActive;
            if (chkIsActive.Checked)
            {
                isActive = true;
            }
            else 
            {
                isActive = false;
            }
            UserBiz biz = new UserBiz();
            UserEntity T = new UserEntity();
            T.UserName = txtUserName.Text;
            T.Password = txtPassword.Text;
            T.Email = txtEmail.Text;
            T.RoleId = Convert.ToInt32(drdRole.SelectedValue);
            T.IsActive = isActive;
            bool result;

            if (string.IsNullOrEmpty(id))
            {
               
               result = biz.Insert(T);
            }
            else 
            {
                T.Id = Convert.ToInt32(id);
                result = biz.Update(T);                
            }
        }
    }
}