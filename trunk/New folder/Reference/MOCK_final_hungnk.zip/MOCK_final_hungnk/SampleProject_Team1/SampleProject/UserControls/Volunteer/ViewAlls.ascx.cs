﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SampleProject.Biz;
using SampleProject.Commons;
using SampleProject.Entity;
namespace SampleProject.UserControls.Volunteer
{
    public partial class ViewAlls : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            string startWiths = this.Request.QueryString["startwith"];
            bool isActive = string.IsNullOrEmpty(this.Request.QueryString["isActive"]) ? true : (this.Request.QueryString["isActive"] == "1");
            VolunteerBiz biz = new VolunteerBiz();
            List<VolunteeringEntity> volunterr;
            if (!string.IsNullOrEmpty(startWiths))
            {
                volunterr = biz.GetByStartWiths(startWiths, Constants.Volunteering.SqlColumn.VolunteeringContact, isActive);
                GridView2.DataSource = volunterr;
                GridView2.DataBind();
            }
            else
            {
                if (isActive)
                {
                    volunterr = biz.GetActived();
                    GridView2.DataSource = volunterr;
                    GridView2.DataBind();
                }
                else
                {
                    volunterr = biz.GetAll();
                    GridView2.DataSource = volunterr;
                    GridView2.DataBind();
                }
            } 
        }
    }
}