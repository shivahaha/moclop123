﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SampleProject.Biz;
using SampleProject.Commons;
using SampleProject.Entity;
using System.Data;

namespace SampleProject.UserControls.trust_region
{
    public partial class Details : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                CountriesBiz countryBiz = new CountriesBiz();
                DataTable Country = countryBiz.GetAllWithOutQuery1();

                ddlNation.DataSource = Country;
                ddlNation.DataValueField = "CountryId";
                ddlNation.DataTextField = "CountryName";
                ddlNation.DataBind();

                string id = this.Request.QueryString["id"];
                int userId = Convert.ToInt32(id);
                TrustRegionBiz trustRegion = new TrustRegionBiz();
                TrustRegionsEntity T = trustRegion.GetById(userId);
                if (string.IsNullOrEmpty(id))
                {
                }
                else
                {
                    txtTrustRegionName.Text = T.TrustRegionName.ToString();
                    txtDescription.Text = T.Description.ToString();
                    ddlNation.SelectedValue = T.CountryId.ToString();
                  
                }

            }
        }
    }
}