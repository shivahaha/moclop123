﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SampleProject.Biz;
using SampleProject.Commons;
using SampleProject.Entity;

namespace SampleProject.UserControls.Facility
{
    public partial class WebUserControl1 : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string startWiths = this.Request.QueryString["startwith"];
            bool isActive = string.IsNullOrEmpty(this.Request.QueryString["isActive"]) ? true : (this.Request.QueryString["isActive"] == "1");
            FacilityBiz biz = new FacilityBiz();
            GridViewFacilityList.DataBind();
           // List<FacilityEntity> directory;
            if (!string.IsNullOrEmpty(startWiths))
            {
               // directory = biz.GetByStartWiths(startWiths, Constants.Facility.SqlColumn.FacilityType, isActive);
            }
            else
            {
                if (isActive)
                {
                 //   directory = biz.GetActived();
                 //   GridView1.DataSource = directory;
                  //  GridView1.DataBind();
                }
                else
                {
                   // directory = biz.GetAll();
                   // GridView1.DataSource = directory;
                   // GridView1.DataBind();
                }
            }

        }      
    }
}