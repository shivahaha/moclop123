﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SampleProject.Biz;
using SampleProject.Commons;
using SampleProject.Entity;

namespace SampleProject.UserControls.Contact
{
    public partial class ViewAlls : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                string startWiths = this.Request.QueryString["startwith"];
                bool isActive = string.IsNullOrEmpty(this.Request.QueryString["isActive"]) ? true : (this.Request.QueryString["isActive"] == "1");
                ContactBiz biz = new ContactBiz();
                List<ContactEntity> contact;
                if (!string.IsNullOrEmpty(startWiths))
                {
                    contact = biz.GetByStartWiths(startWiths, Constants.Contact.SqlColumn.FirstName, isActive);
                    GridView1.DataSource = contact;
                    GridView1.DataBind();
                }
                else
                {
                    if (isActive)
                    {
                        contact = biz.GetActived();
                        GridView1.DataSource = contact;
                        GridView1.DataBind();
                    }
                    else
                    {
                        contact = biz.GetAll();
                        GridView1.DataSource = contact;
                        GridView1.DataBind();
                    }
                }
        }
    }
}