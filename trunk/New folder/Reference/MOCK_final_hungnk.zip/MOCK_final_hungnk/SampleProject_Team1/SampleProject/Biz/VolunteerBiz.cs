﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SampleProject.Commons;
using SampleProject.Entity;
using SampleProject.DAO;
namespace SampleProject.Biz
{
    public class VolunteerBiz:BaseBiz<VolunteeringEntity>
    {
         public VolunteerBiz() : base(Constants.Volunteering.TableName, Constants.Volunteering.Query1, Constants.Volunteering.Query2) { }
    }
}