﻿using System.Collections.Generic;
using SampleProject.DAO;
using SampleProject.Entity;
using System.Data;
using System.Data.SqlTypes;
using System;
namespace SampleProject.Biz
{
    public class BaseBiz<T> where T : IEntity
    {
        public string TableName { get; private set; }
        public string Query1 { get; private set; }
        public string Query2 { get; private set; }
        public BaseBiz(string tableName) 
        {
            this.TableName = tableName;
        }
        public BaseBiz(string tableName, string query1, string query2)
        {
            this.TableName = tableName;
            this.Query1 = query1;
            this.Query2 = query2;
        }

        public List<T> GetAll()
        {
            BaseDAO<T> dao = new BaseDAO<T>(this.TableName);
            return dao.GetAll(this.Query1, this.Query2);
        }

        public bool Insert(IEntity entity)
        {
            BaseDAO<T> dao = new BaseDAO<T>(this.TableName);
            return dao.Insert(entity);
        }

        public bool Update(IEntity entity)
        {
            BaseDAO<T> dao = new BaseDAO<T>(this.TableName);
            return dao.Update(entity);
        }

        public bool Delete(int id)
        {
            BaseDAO<T> dao = new BaseDAO<T>(this.TableName);
            return dao.Delete(id);
        }

        public T GetById(int id)
        {
            BaseDAO<T> dao = new BaseDAO<T>(this.TableName);
            return dao.GetById(this.Query1,this.Query2,id);
        }

        public List<T> GetActived()
        {
            BaseDAO<T> dao = new BaseDAO<T>(this.TableName);
            return dao.GetActived(this.Query1, this.Query2);
        }

        public List<T> GetByStartWiths(string startWiths, string columnName, bool isActive)
        {
            BaseDAO<T> dao = new BaseDAO<T>(this.TableName);
            return dao.GetByStartWiths(this.Query1,this.Query2,startWiths,columnName, isActive);
        }
        public List<T> GetAllWithOutQuery() 
        {
             BaseDAO<T> dao = new BaseDAO<T>(this.TableName);
             return dao.GetAllWithOutQuery();
        }
        /// <summary>
        /// Tạm thời dùng cách DataTable
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllWithOutQuery1() 
        {
            BaseDAO<T> dao = new BaseDAO<T>(this.TableName);
            return dao.GetAllWithOutQuery1();
        }
    }
}