﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SampleProject.Entity;
using SampleProject.Commons;
using SampleProject.DAO;
using System.Data;

namespace SampleProject.Biz
{
    public class RoleBiz : BaseBiz<RoleEntity>
    {
        public RoleBiz() : base(Constants.Role.TableName) { }
       
        public List<RoleEntity> GetAllWithOutQuery()
        {            
            return base.GetAllWithOutQuery();
        }
        public DataTable GetAllWithOutQuery1()
        {
            return base.GetAllWithOutQuery1();
        }
    }
}