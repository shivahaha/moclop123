﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SampleProject.Entity;
using SampleProject.Commons;
using SampleProject.DAO;

namespace SampleProject.Biz
{
    public class FacilityBiz : BaseBiz<AddressEntity>
    {
        public FacilityBiz() : base(Constants.Facility.TableName, Constants.Facility.Query1, Constants.Facility.Query2) { }
    }
}