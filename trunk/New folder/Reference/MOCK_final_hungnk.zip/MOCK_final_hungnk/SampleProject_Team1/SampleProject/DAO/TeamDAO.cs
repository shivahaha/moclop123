﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SampleProject.Commons;
using SampleProject.Entity;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace SampleProject.DAO
{
    //public class TeamDAO : BaseDAO<TeamEntity>
    //{
    //    public TeamDAO() : base(Constants.Teams.TableName) { }

    //    public List<TeamEntity> GetAll()
    //    {
    //        string query1 = "Contacts";
    //        string query2 = "Contacts.ContactId = Teams.ContactId";
    //        return base.GetAll(query1,query2);
    //    }
    //    public bool Insert(IEntity entity)
    //    {
    //        return base.Insert(entity);
    //    }

    //    public bool Update(IEntity entity)
    //    {
    //        return base.Update(entity);
    //    }

    //    public bool Delete(int id)
    //    {
    //        return base.Delete(id);
    //    }

    //    public TeamEntity GetById(int id)
    //    {
    //        return base.GetById(id);
    //    }

    //    public List<TeamEntity> GetByStartWiths(string startWiths, string columnName, bool isActived)
    //    {
    //        return base.GetByStartWiths(startWiths, columnName, isActived);
    //    }
    //    public List<TeamEntity> GetActived()
    //    {
    //        return base.GetActived(query1, query2);
    //    }
    //    private IEntity Mapping(DataRow row)
    //    {
    //        IEntity retVal;
    //        retVal = new TeamEntity();
    //        retVal.Mapping(row);
    //        return retVal;
    //    }
    //    public List<TeamEntity> GetSample()
    //    {
    //        List<TeamEntity> retVal = new List<TeamEntity>();
    //        DataSet dataset = new DataSet();
    //        string connStr = ConfigurationManager.ConnectionStrings[Constants.Configurations.Keys.SQLConnectionString].ConnectionString;
    //        using (SqlConnection conn = new SqlConnection(connStr))
    //        {

    //            SqlCommand cmd = new SqlCommand(@"select * from Teams, Contacts where Teams.ContactId=Contacts.ContactId", conn);
    //            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
    //            {
    //                da.Fill(dataset);
    //                if (dataset.Tables.Count > 0)
    //                {
    //                    DataTable tbl = dataset.Tables[0];
    //                    var count = tbl.Rows.Count;
    //                    for (int i = 0; i < count; i++)
    //                    {
    //                        DataRow row = tbl.Rows[i];
    //                        TeamEntity entity = (TeamEntity)Mapping(row);
    //                        if (entity != null)
    //                        {
    //                            retVal.Add(entity);
    //                        }
    //                    }
    //                }
    //            }
    //        }
    //        return retVal;
    //    }
    //}
}