﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SampleProject.DAO
{
    public class MinorWorkProjectDAO
    {
    }
}