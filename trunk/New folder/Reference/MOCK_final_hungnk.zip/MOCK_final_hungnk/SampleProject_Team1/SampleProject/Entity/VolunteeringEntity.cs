﻿using System;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SampleProject.Commons;

namespace SampleProject.Entity
{
    public class VolunteeringEntity : IEntity
    {
        public int Id { get; set; }
        public string VolunteeringContact { get; set; }
        public string VolunteerPurpose { get; set; }
        public string VolunteeringOpportunityDetails { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int VolunteerNos { get; set; }

        public void Mapping(DataRow row)
        {
            Id = (row[Constants.Volunteering.SqlColumn.Id] == null
              || row[Constants.Volunteering.SqlColumn.Id] is DBNull) ? 0
              : int.Parse(row[Constants.Volunteering.SqlColumn.Id].ToString());
            VolunteeringContact = (row[Constants.Volunteering.SqlColumn.VolunteeringContact] == null || row[Constants.Volunteering.SqlColumn.VolunteeringContact] is DBNull) ? string.Empty : row[Constants.Volunteering.SqlColumn.VolunteeringContact].ToString();
            VolunteerPurpose = (row[Constants.Volunteering.SqlColumn.VolunteerPurpose] == null || row[Constants.Volunteering.SqlColumn.VolunteerPurpose] is DBNull) ? string.Empty : row[Constants.Volunteering.SqlColumn.VolunteerPurpose].ToString();
            VolunteeringOpportunityDetails = (row[Constants.Volunteering.SqlColumn.VolunteeringOpportunityDetails] == null || row[Constants.Volunteering.SqlColumn.VolunteeringOpportunityDetails] is DBNull) ? string.Empty : row[Constants.Volunteering.SqlColumn.VolunteeringOpportunityDetails].ToString();
            StartDate = Convert.ToDateTime((row[Constants.Volunteering.SqlColumn.StartDate] == null || row[Constants.Volunteering.SqlColumn.StartDate] is DBNull) ? string.Empty : row[Constants.Volunteering.SqlColumn.StartDate].ToString());
            EndDate = Convert.ToDateTime((row[Constants.Volunteering.SqlColumn.EndDate] == null || row[Constants.Volunteering.SqlColumn.EndDate] is DBNull) ? string.Empty : row[Constants.Volunteering.SqlColumn.EndDate].ToString());
            VolunteerNos = Convert.ToInt32((row[Constants.Volunteering.SqlColumn.VolunteerNos] == null || row[Constants.Volunteering.SqlColumn.VolunteerNos] is DBNull) ? string.Empty : row[Constants.Volunteering.SqlColumn.VolunteerNos].ToString());
        }

        public SqlCommand UpdateCommand(string tableName)
        {
            SqlCommand retVal = new SqlCommand();
            retVal.CommandType = CommandType.Text;
            const string cmdStr = "UPDATE Volunteering SET " +
                                      "VolunteeringContact = @VolunteeringContact, " +
                                      "VolunteerPurpose = @VolunteerPurpose, " +
                                      "VolunteeringOpportunityDetails = @VolunteeringOpportunityDetails, " +
                                      "StartDate = @StartDate, " +
                                      "EndDate = @EndDate " +
                                      "VolunteerNos = @VolunteerNos" +
                                  "WHERE Id = @Id";
            retVal.CommandText = string.Format(cmdStr, tableName, Constants.Volunteering.SqlColumn.VolunteeringContact, Constants.Volunteering.SqlColumn.VolunteerPurpose, Constants.Volunteering.SqlColumn.VolunteeringOpportunityDetails, Constants.Volunteering.SqlColumn.StartDate, Constants.Volunteering.SqlColumn.EndDate, Constants.Volunteering.SqlColumn.VolunteerNos);
            retVal.Parameters.Add(new SqlParameter("VolunteeringContact", VolunteeringContact));
            retVal.Parameters.Add(new SqlParameter("VolunteerPurpose", VolunteerPurpose));
            retVal.Parameters.Add(new SqlParameter("VolunteeringOpportunityDetails", VolunteeringOpportunityDetails));
            retVal.Parameters.Add(new SqlParameter("StartDate", StartDate));
            retVal.Parameters.Add(new SqlParameter("EndDate", EndDate));
            retVal.Parameters.Add(new SqlParameter("VolunteerNos", VolunteerNos));
            retVal.Parameters.Add(new SqlParameter("Id", Id));
            return retVal;
        }

        public SqlCommand InsertCommand(string tableName)
        {
            SqlCommand retVal = new SqlCommand();
            retVal.CommandType = CommandType.Text;
            const string cmdStr = "INSERT INTO Volunteering VALUES(" +
                                  "@VolunteeringContact, " +
                                  "@VolunteerPurpose, " +
                                  "@VolunteeringOpportunityDetails, " +
                                  "@StartDate, " +
                                  "@EndDate" +
                                  "@VolunteerNos)";
            retVal.CommandText = string.Format(cmdStr, tableName, Constants.Volunteering.SqlColumn.VolunteeringContact, Constants.Volunteering.SqlColumn.VolunteerPurpose, Constants.Volunteering.SqlColumn.VolunteeringOpportunityDetails, Constants.Volunteering.SqlColumn.StartDate, Constants.Volunteering.SqlColumn.EndDate, Constants.Volunteering.SqlColumn.VolunteerNos);
            retVal.Parameters.Add(new SqlParameter("VolunteeringContact", VolunteeringContact));
            retVal.Parameters.Add(new SqlParameter("VolunteerPurpose", VolunteerPurpose));
            retVal.Parameters.Add(new SqlParameter("VolunteeringOpportunityDetails", VolunteeringOpportunityDetails));
            retVal.Parameters.Add(new SqlParameter("StartDate", StartDate));
            retVal.Parameters.Add(new SqlParameter("EndDate", EndDate));
            retVal.Parameters.Add(new SqlParameter("VolunteerNos", VolunteerNos));
            return retVal;
        }
    }
}
