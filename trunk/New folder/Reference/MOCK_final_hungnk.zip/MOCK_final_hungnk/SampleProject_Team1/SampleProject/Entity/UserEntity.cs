﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SampleProject.Commons;
using System.Data.SqlClient;
using System.Data;

namespace SampleProject.Entity
{
    public class UserEntity : IEntity
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public int RoleId { get; set; }
        public int Id { get; set; }
        public string RoleName { get; set; }
        public string Email { get; set; }
        public bool IsActive { get; set; }

        void IEntity.Mapping(DataRow row)
        {
            UserName = (row[Constants.User.SqlColumn.UserName] == null || row[Constants.User.SqlColumn.UserName] is DBNull) ? string.Empty : row[Constants.User.SqlColumn.UserName].ToString();
            Password = (row[Constants.User.SqlColumn.Password] == null || row[Constants.User.SqlColumn.Password] is DBNull) ? string.Empty : row[Constants.User.SqlColumn.Password].ToString();
            Id = (row[Constants.User.SqlColumn.Id] == null
                || row[Constants.User.SqlColumn.Id] is DBNull) ? 0
                : int.Parse(row[Constants.User.SqlColumn.Id].ToString());
            Email = (row[Constants.User.SqlColumn.Email] == null || row[Constants.User.SqlColumn.Email] is DBNull) ? string.Empty : row[Constants.User.SqlColumn.Email].ToString();
            IsActive = (row[Constants.User.SqlColumn.IsActive] == null || row[Constants.User.SqlColumn.IsActive] is DBNull) ? false : Convert.ToBoolean(row[Constants.User.SqlColumn.IsActive].ToString());

            RoleId = (row[Constants.User.SqlColumn.RoleId] == null
                || row[Constants.User.SqlColumn.RoleId] is DBNull) ? 0
                : int.Parse(row[Constants.User.SqlColumn.RoleId].ToString());
            RoleName = (row[Constants.Role.SqlColumn.RoleName] == null || row[Constants.Role.SqlColumn.RoleName] is DBNull) ? string.Empty : row[Constants.Role.SqlColumn.RoleName].ToString();
        }

        SqlCommand IEntity.UpdateCommand(string tableName)
        {
            SqlCommand retVal = new SqlCommand();
            retVal.CommandType = CommandType.Text;
            string cmdStr = "Update [{0}] set [{1}] = @param1, [{2}] = @param2,[{3}] = @param3,[{4}] = @param4,[{5}] = @param5 where UserId = @id";
            retVal.CommandText = string.Format(cmdStr, tableName, Constants.User.SqlColumn.UserName, Constants.User.SqlColumn.Password,Constants.User.SqlColumn.RoleId, Constants.User.SqlColumn.Email, Constants.User.SqlColumn.IsActive);
            retVal.Parameters.Add(new SqlParameter("param1", UserName));
            retVal.Parameters.Add(new SqlParameter("param2", Password));
            retVal.Parameters.Add(new SqlParameter("param3", RoleId));
            retVal.Parameters.Add(new SqlParameter("param4", Email));
            retVal.Parameters.Add(new SqlParameter("param5", IsActive));
            retVal.Parameters.Add(new SqlParameter("id", Id));
            return retVal;
        }

        SqlCommand IEntity.InsertCommand(string tableName)
        {
            SqlCommand retVal = new SqlCommand();
            retVal.CommandType = CommandType.Text;
            string cmdStr = "Insert into [{0}] ([{1}],[{2}],[{3}],[{4}],[{5}]) values(@param1, @param2,@param3,@param4,@param5)";
            retVal.CommandText = string.Format(cmdStr, tableName, Constants.User.SqlColumn.UserName, Constants.User.SqlColumn.Password, Constants.User.SqlColumn.RoleId, Constants.User.SqlColumn.Email, Constants.User.SqlColumn.IsActive);
            retVal.Parameters.Add(new SqlParameter("param1", UserName));
            retVal.Parameters.Add(new SqlParameter("param2", Password));
            retVal.Parameters.Add(new SqlParameter("param3", RoleId));
            retVal.Parameters.Add(new SqlParameter("param4", Email));
            retVal.Parameters.Add(new SqlParameter("param5", IsActive));
            return retVal;
        }
    }
}