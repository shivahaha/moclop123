﻿using System;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SampleProject.Commons;

namespace SampleProject.Entity
{
    public class FacilityEntity : IEntity
    {
        public int Id{ get; set; }
        public string FacilityType { get; set; }
        public string FacilityDescription { get; set; }
        public string RoomCapacity { get; set; }
        public string RoomSize { get; set; }
        public bool RoomConnectivity { get; set; }
        public string ConnectivityType { get; set; }
        public string WirelessAccessInformation { get; set; }
        public int LeadContactId { get; set; }
        public int RoomHostId { get; set; }
        public bool EquipmentAvailable { get; set; }
        public string RoomEquipmentNotes { get; set; }

        public void Mapping(DataRow row)
        {
            FacilityType = (row[Constants.Facility.SqlColumn.FacilityType] == null || row[Constants.Facility.SqlColumn.FacilityType] is DBNull) ? string.Empty : row[Constants.Facility.SqlColumn.FacilityType].ToString();
            FacilityDescription = (row[Constants.Facility.SqlColumn.FacilityDescription] == null || row[Constants.Facility.SqlColumn.FacilityDescription] is DBNull) ? string.Empty : row[Constants.Facility.SqlColumn.FacilityDescription].ToString();
            RoomCapacity = (row[Constants.Facility.SqlColumn.RoomCapacity] == null || row[Constants.Facility.SqlColumn.RoomCapacity] is DBNull) ? string.Empty : row[Constants.Facility.SqlColumn.RoomCapacity].ToString();
            RoomSize = (row[Constants.Facility.SqlColumn.RoomSize] == null || row[Constants.Facility.SqlColumn.FacilityType] is DBNull) ? string.Empty : row[Constants.Facility.SqlColumn.FacilityType].ToString();
            RoomConnectivity = Convert.ToBoolean((row[Constants.Facility.SqlColumn.RoomConnectivity] == null || row[Constants.Facility.SqlColumn.RoomConnectivity] is DBNull) ? string.Empty : row[Constants.Facility.SqlColumn.RoomConnectivity].ToString());
            ConnectivityType = (row[Constants.Facility.SqlColumn.ConnectivityType] == null || row[Constants.Facility.SqlColumn.ConnectivityType] is DBNull) ? string.Empty : row[Constants.Facility.SqlColumn.ConnectivityType].ToString();
            WirelessAccessInformation = (row[Constants.Facility.SqlColumn.WirelessAccessInformation] == null || row[Constants.Facility.SqlColumn.WirelessAccessInformation] is DBNull) ? string.Empty : row[Constants.Facility.SqlColumn.WirelessAccessInformation].ToString();
            LeadContactId = (row[Constants.Facility.SqlColumn.LeadContactId] == null || row[Constants.Facility.SqlColumn.LeadContactId] is DBNull) ? 0 : Convert.ToInt32( row[Constants.Facility.SqlColumn.LeadContactId].ToString());
            RoomHostId = (row[Constants.Facility.SqlColumn.RoomHostId] == null || row[Constants.Facility.SqlColumn.RoomHostId] is DBNull) ? 0 : Convert.ToInt32( row[Constants.Facility.SqlColumn.RoomHostId].ToString());
            EquipmentAvailable = Convert.ToBoolean((row[Constants.Facility.SqlColumn.EquipmentAvailable] == null || row[Constants.Facility.SqlColumn.EquipmentAvailable] is DBNull) ? string.Empty : row[Constants.Facility.SqlColumn.EquipmentAvailable].ToString());
            RoomEquipmentNotes = (row[Constants.Facility.SqlColumn.RoomEquipmentNotes] == null || row[Constants.Facility.SqlColumn.RoomEquipmentNotes] is DBNull) ? string.Empty : row[Constants.Facility.SqlColumn.RoomEquipmentNotes].ToString();
        }

        public SqlCommand UpdateCommand(string tableName)
        {
            SqlCommand retVal = new SqlCommand();
            retVal.CommandType = CommandType.Text;
            const string cmdStr = "UPDATE Facility SET " +
                                      "FacilityType = @FacilityType, " +
                                      "FacilityDescription = @FacilityDescription, " +
                                      "RoomCapacity = @RoomCapacity, " +
                                      "RoomSize = @RoomSize, " +
                                      "RoomConnectivity = @RoomConnectivity, " +
                                      "ConnectivityType = @ConnectivityType, " +
                                      "WirelessAccessInformation = @WirelessAccessInformation, " +
                                      "LeadContact = @LeadContact, " +
                                      "RoomHost = @RoomHost, " +
                                      "EquipmentAvailable = @EquipmentAvailable, " +
                                      "RoomEquipmentNotes = @RoomEquipmentNotes " +
                                  "WHERE Id = @Id";
            retVal.CommandText = string.Format(cmdStr, tableName, Constants.Facility.SqlColumn.FacilityType, Constants.Facility.SqlColumn.FacilityDescription, Constants.Facility.SqlColumn.RoomCapacity, Constants.Facility.SqlColumn.RoomSize, Constants.Facility.SqlColumn.RoomConnectivity, Constants.Facility.SqlColumn.ConnectivityType, Constants.Facility.SqlColumn.WirelessAccessInformation, Constants.Facility.SqlColumn.LeadContactId, Constants.Facility.SqlColumn.RoomHostId, Constants.Facility.SqlColumn.EquipmentAvailable, Constants.Facility.SqlColumn.RoomEquipmentNotes);
            retVal.Parameters.Add(new SqlParameter("FacilityType", FacilityType));
            retVal.Parameters.Add(new SqlParameter("FacilityDescription", FacilityDescription));        
            retVal.Parameters.Add(new SqlParameter("RoomCapacity", RoomCapacity));
            retVal.Parameters.Add(new SqlParameter("RoomSize", RoomSize));
            retVal.Parameters.Add(new SqlParameter("RoomConnectivity", RoomConnectivity));
            retVal.Parameters.Add(new SqlParameter("ConnectivityType", ConnectivityType));
            retVal.Parameters.Add(new SqlParameter("WirelessAccessInformation", WirelessAccessInformation));
            retVal.Parameters.Add(new SqlParameter("LeadContact", LeadContactId));
            retVal.Parameters.Add(new SqlParameter("RoomHost", RoomHostId));
            retVal.Parameters.Add(new SqlParameter("EquipmentAvailable", EquipmentAvailable));
            retVal.Parameters.Add(new SqlParameter("RoomEquipmentNotes", RoomEquipmentNotes));
            retVal.Parameters.Add(new SqlParameter("Id", Id));
            return retVal;
        }

        public SqlCommand InsertCommand(string tableName)
        {
            SqlCommand retVal = new SqlCommand();
            retVal.CommandType = CommandType.Text;
            const string cmdStr = "INSERT INTO Facility VALUES(" +
                                  "@FacilityType, " +
                                  "@FacilityDescription, " +
                                  "@RoomCapacity, " +
                                  "@RoomSize, " +
                                  "@RoomConnectivity, " +
                                  "@ConnectivityType, " +
                                  "@WirelessAccessInformation, " +
                                  "@LeadContact, " +
                                  "@RoomHost, " +
                                  "@EquipmentAvailable, " +
                                  "@RoomEquipmentNotes)";
            retVal.CommandText = string.Format(cmdStr, tableName, Constants.Facility.SqlColumn.FacilityType, Constants.Facility.SqlColumn.FacilityDescription, Constants.Facility.SqlColumn.RoomCapacity, Constants.Facility.SqlColumn.RoomSize, Constants.Facility.SqlColumn.RoomConnectivity, Constants.Facility.SqlColumn.ConnectivityType, Constants.Facility.SqlColumn.WirelessAccessInformation, Constants.Facility.SqlColumn.LeadContactId, Constants.Facility.SqlColumn.RoomHostId, Constants.Facility.SqlColumn.EquipmentAvailable, Constants.Facility.SqlColumn.RoomEquipmentNotes);
            retVal.Parameters.Add(new SqlParameter("FacilityType", FacilityType));
            retVal.Parameters.Add(new SqlParameter("FacilityDescription", FacilityDescription));
            retVal.Parameters.Add(new SqlParameter("RoomCapacity", RoomCapacity));
            retVal.Parameters.Add(new SqlParameter("RoomSize", RoomSize));
            retVal.Parameters.Add(new SqlParameter("RoomConnectivity", RoomConnectivity));
            retVal.Parameters.Add(new SqlParameter("ConnectivityType", ConnectivityType));
            retVal.Parameters.Add(new SqlParameter("WirelessAccessInformation", WirelessAccessInformation));
            retVal.Parameters.Add(new SqlParameter("LeadContact", LeadContactId));
            retVal.Parameters.Add(new SqlParameter("RoomHost", RoomHostId));
            retVal.Parameters.Add(new SqlParameter("EquipmentAvailable", EquipmentAvailable));
            retVal.Parameters.Add(new SqlParameter("RoomEquipmentNotes", RoomEquipmentNotes));
            return retVal;
        }
    }
}
