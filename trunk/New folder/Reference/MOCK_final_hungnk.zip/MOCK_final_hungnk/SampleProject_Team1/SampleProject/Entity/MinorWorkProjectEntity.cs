﻿using System;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SampleProject.Commons;

namespace SampleProject.Entity
{
    public class MinorWorkProjectEntity : IEntity
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public string ProjectOrMinor { get; set; }
        public bool IsTBA { get; set; }
        public string NotesActions { get; set; }
        public float EstimatedCost { get; set; }
        public float ActualCost { get; set; }
        public int DirectorateId { get; set; }
        public int ContactId { get; set; }
        public string AuthorisedByName { get; set; }
        public string Status { get; set; }
        public DateTime PMWEnquiryReceivedDate { get; set; }
        public DateTime AuthorisedDate { get; set; }
        public DateTime ActualStartDate { get; set; }
        public DateTime AnticipatedCompletion { get; set; }
        public DateTime ActualCompletionDate { get; set; }


        public void Mapping(DataRow row)
        {
            Description = (row[Constants.MinorWorkProject.SqlColumn.Description] == null || row[Constants.MinorWorkProject.SqlColumn.Description] is DBNull) ? string.Empty : row[Constants.MinorWorkProject.SqlColumn.Description].ToString();
            ProjectOrMinor = (row[Constants.MinorWorkProject.SqlColumn.ProjectOrMinor] == null || row[Constants.MinorWorkProject.SqlColumn.Description] is DBNull) ? string.Empty : row[Constants.MinorWorkProject.SqlColumn.Description].ToString();
            IsTBA = Convert.ToBoolean((row[Constants.MinorWorkProject.SqlColumn.IsTBA] == null || row[Constants.MinorWorkProject.SqlColumn.IsTBA] is DBNull) ? string.Empty : row[Constants.MinorWorkProject.SqlColumn.IsTBA].ToString());
            NotesActions = (row[Constants.MinorWorkProject.SqlColumn.NotesActions] == null || row[Constants.MinorWorkProject.SqlColumn.NotesActions] is DBNull) ? string.Empty : row[Constants.MinorWorkProject.SqlColumn.NotesActions].ToString();
            EstimatedCost = Convert.ToSingle((row[Constants.MinorWorkProject.SqlColumn.EstimatedCost] == null || row[Constants.MinorWorkProject.SqlColumn.EstimatedCost] is DBNull) ? string.Empty : row[Constants.MinorWorkProject.SqlColumn.EstimatedCost].ToString());
            ActualCost = Convert.ToSingle((row[Constants.MinorWorkProject.SqlColumn.ActualCost] == null || row[Constants.MinorWorkProject.SqlColumn.ActualCost] is DBNull) ? string.Empty : row[Constants.MinorWorkProject.SqlColumn.ActualCost].ToString());
            DirectorateId = (row[Constants.MinorWorkProject.SqlColumn.DirectorateId] == null || row[Constants.MinorWorkProject.SqlColumn.DirectorateId] is DBNull)? 0 : Convert.ToInt32(row[Constants.MinorWorkProject.SqlColumn.DirectorateId].ToString());
            ContactId = (row[Constants.MinorWorkProject.SqlColumn.ContactId] == null || row[Constants.MinorWorkProject.SqlColumn.ContactId] is DBNull) ? 0 : Convert.ToInt32(row[Constants.MinorWorkProject.SqlColumn.ContactId].ToString());
            AuthorisedByName = (row[Constants.MinorWorkProject.SqlColumn.AuthorisedByName] == null || row[Constants.MinorWorkProject.SqlColumn.Description] is DBNull) ? string.Empty : row[Constants.MinorWorkProject.SqlColumn.Description].ToString();
            Status = (row[Constants.MinorWorkProject.SqlColumn.Description] == null || row[Constants.MinorWorkProject.SqlColumn.AuthorisedByName] is DBNull) ? string.Empty : row[Constants.MinorWorkProject.SqlColumn.AuthorisedByName].ToString();
            PMWEnquiryReceivedDate = Convert.ToDateTime((row[Constants.MinorWorkProject.SqlColumn.PMWEnquiryReceivedDate] == null || row[Constants.MinorWorkProject.SqlColumn.PMWEnquiryReceivedDate] is DBNull) ? string.Empty : row[Constants.MinorWorkProject.SqlColumn.PMWEnquiryReceivedDate].ToString());
            AuthorisedDate = Convert.ToDateTime((row[Constants.MinorWorkProject.SqlColumn.AuthorisedDate] == null || row[Constants.MinorWorkProject.SqlColumn.AuthorisedDate] is DBNull) ? string.Empty : row[Constants.MinorWorkProject.SqlColumn.AuthorisedDate].ToString());
            ActualStartDate = Convert.ToDateTime((row[Constants.MinorWorkProject.SqlColumn.ActualStartDate] == null || row[Constants.MinorWorkProject.SqlColumn.ActualStartDate] is DBNull) ? string.Empty : row[Constants.MinorWorkProject.SqlColumn.ActualStartDate].ToString());
            AnticipatedCompletion = Convert.ToDateTime((row[Constants.MinorWorkProject.SqlColumn.AnticipatedCompletion] == null || row[Constants.MinorWorkProject.SqlColumn.AnticipatedCompletion] is DBNull) ? string.Empty : row[Constants.MinorWorkProject.SqlColumn.AnticipatedCompletion].ToString());
            ActualCompletionDate = Convert.ToDateTime((row[Constants.MinorWorkProject.SqlColumn.ActualCompletionDate] == null || row[Constants.MinorWorkProject.SqlColumn.ActualCompletionDate] is DBNull) ? string.Empty : row[Constants.MinorWorkProject.SqlColumn.ActualCompletionDate].ToString());
        }

        public SqlCommand UpdateCommand(string tableName)
        {
            SqlCommand retVal = new SqlCommand();
            retVal.CommandType = CommandType.Text;
            const string cmdStr = "UPDATE MinorWorkProject SET " +
                                      "Description = @Description, " +
                                      "ProjectOrMinor = @ProjectOrMinor, " +
                                      "IsTBA = @IsTBA, " +
                                      "NotesActions = @NotesActions, " +
                                      "EstimatedCost = @EstimatedCost " +
                                      "Directorate = @Directorate " +
                                      "ActualCost = @ActualCost " +
                                      "Contact = @Contact " +
                                      "AuthorisedByName = @AuthorisedByName " +
                                      "Status = @Status " +
                                      "PMWEnquiryReceivedDate = @StaPMWEnquiryReceivedDatetus " +
                                      "AuthorisedDate = @AuthorisedDate " +
                                      "ActualStartDate = @ActualStartDate " +
                                      "AnticipatedCompletion = @AnticipatedCompletion " +
                                      "ActualCompletionDate = @ActualCompletionDate " +
                                  "WHERE Id = @Id";
            retVal.CommandText = string.Format(cmdStr, tableName, Constants.MinorWorkProject.SqlColumn.Description, Constants.MinorWorkProject.SqlColumn.ProjectOrMinor, Constants.MinorWorkProject.SqlColumn.IsTBA, Constants.MinorWorkProject.SqlColumn.NotesActions, Constants.MinorWorkProject.SqlColumn.EstimatedCost, Constants.MinorWorkProject.SqlColumn.ActualCost, Constants.MinorWorkProject.SqlColumn.DirectorateId, Constants.MinorWorkProject.SqlColumn.ContactId, Constants.MinorWorkProject.SqlColumn.AuthorisedByName, Constants.MinorWorkProject.SqlColumn.Status, Constants.MinorWorkProject.SqlColumn.PMWEnquiryReceivedDate, Constants.MinorWorkProject.SqlColumn.AuthorisedDate, Constants.MinorWorkProject.SqlColumn.ActualStartDate, Constants.MinorWorkProject.SqlColumn.AnticipatedCompletion, Constants.MinorWorkProject.SqlColumn.ActualCompletionDate);
            retVal.Parameters.Add(new SqlParameter("Description", Description));
            retVal.Parameters.Add(new SqlParameter("ProjectOrMinor", ProjectOrMinor));
            retVal.Parameters.Add(new SqlParameter("IsTBA", IsTBA));
            retVal.Parameters.Add(new SqlParameter("NotesActions", NotesActions));
            retVal.Parameters.Add(new SqlParameter("EstimatedCost", EstimatedCost));
            retVal.Parameters.Add(new SqlParameter("Directorate", DirectorateId));
            retVal.Parameters.Add(new SqlParameter("ActualCost", ActualCost));
            retVal.Parameters.Add(new SqlParameter("Contact", ContactId));
            retVal.Parameters.Add(new SqlParameter("AuthorisedByName", AuthorisedByName));
            retVal.Parameters.Add(new SqlParameter("Status", Status));
            retVal.Parameters.Add(new SqlParameter("PMWEnquiryReceivedDate", PMWEnquiryReceivedDate));
            retVal.Parameters.Add(new SqlParameter("AuthorisedDate", AuthorisedDate));
            retVal.Parameters.Add(new SqlParameter("ActualStartDate", ActualStartDate));
            retVal.Parameters.Add(new SqlParameter("AnticipatedCompletion", AnticipatedCompletion));
            retVal.Parameters.Add(new SqlParameter("ActualCompletionDate", ActualCompletionDate));
            retVal.Parameters.Add(new SqlParameter("Id", Id));
            return retVal;
        }

        public SqlCommand InsertCommand(string tableName)
        {
            SqlCommand retVal = new SqlCommand();
            retVal.CommandType = CommandType.Text;
            const string cmdStr = "INSERT INTO MinorWorkProject VALUES(" +
                                  "@Description, " +
                                  "@ProjectOrMinor, " +
                                  "@IsTBA, " +
                                  "@NotesActions, " +
                                  "@EstimatedCost, " +
                                  "@Directorate, " +
                                  "@ActualCost, " +
                                  "@Contact, " +
                                  "@AuthorisedByName, " +
                                  "@Status, " +
                                  "@PMWEnquiryReceivedDate, " +
                                  "@AuthorisedDate, " +
                                  "@ActualStartDate, " +
                                  "@AnticipatedCompletion, " +
                                  "@ActualCompletionDate)";
            retVal.CommandText = string.Format(cmdStr, tableName, Constants.MinorWorkProject.SqlColumn.Description, Constants.MinorWorkProject.SqlColumn.ProjectOrMinor, Constants.MinorWorkProject.SqlColumn.IsTBA, Constants.MinorWorkProject.SqlColumn.NotesActions, Constants.MinorWorkProject.SqlColumn.EstimatedCost, Constants.MinorWorkProject.SqlColumn.ActualCost, Constants.MinorWorkProject.SqlColumn.DirectorateId, Constants.MinorWorkProject.SqlColumn.ContactId, Constants.MinorWorkProject.SqlColumn.AuthorisedByName, Constants.MinorWorkProject.SqlColumn.Status, Constants.MinorWorkProject.SqlColumn.PMWEnquiryReceivedDate, Constants.MinorWorkProject.SqlColumn.AuthorisedDate, Constants.MinorWorkProject.SqlColumn.ActualStartDate, Constants.MinorWorkProject.SqlColumn.AnticipatedCompletion, Constants.MinorWorkProject.SqlColumn.ActualCompletionDate);
            retVal.Parameters.Add(new SqlParameter("Description", Description));
            retVal.Parameters.Add(new SqlParameter("ProjectOrMinor", ProjectOrMinor));
            retVal.Parameters.Add(new SqlParameter("IsTBA", IsTBA));
            retVal.Parameters.Add(new SqlParameter("NotesActions", NotesActions));
            retVal.Parameters.Add(new SqlParameter("EstimatedCost", EstimatedCost));
            retVal.Parameters.Add(new SqlParameter("Directorate", DirectorateId));
            retVal.Parameters.Add(new SqlParameter("ActualCost", ActualCost));
            retVal.Parameters.Add(new SqlParameter("Contact", ContactId));
            retVal.Parameters.Add(new SqlParameter("AuthorisedByName", AuthorisedByName));
            retVal.Parameters.Add(new SqlParameter("Status", Status));
            retVal.Parameters.Add(new SqlParameter("PMWEnquiryReceivedDate", PMWEnquiryReceivedDate));
            retVal.Parameters.Add(new SqlParameter("AuthorisedDate", AuthorisedDate));
            retVal.Parameters.Add(new SqlParameter("ActualStartDate", ActualStartDate));
            retVal.Parameters.Add(new SqlParameter("AnticipatedCompletion", AnticipatedCompletion));
            retVal.Parameters.Add(new SqlParameter("ActualCompletionDate", ActualCompletionDate));
            return retVal;
        }
    }
}
