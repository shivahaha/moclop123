﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SampleProject.Commons;
using System.Data.SqlClient;
using System.Data;

namespace SampleProject.Entity
{
    public class RoleEntity : IEntity
    { 
        public int Id { get; set; }
        public string RoleName { get; set; }       
        void IEntity.Mapping(DataRow row)
        {
            
            Id = (row[Constants.Role.SqlColumn.Id] == null
                || row[Constants.Role.SqlColumn.Id] is DBNull) ? 0
                : int.Parse(row[Constants.User.SqlColumn.RoleId].ToString());          

            RoleName = (row[Constants.Role.SqlColumn.RoleName] == null || row[Constants.Role.SqlColumn.RoleName] is DBNull) ? string.Empty : row[Constants.Role.SqlColumn.RoleName].ToString();
        }

        SqlCommand IEntity.UpdateCommand(string tableName)
        {
            SqlCommand retVal = new SqlCommand();
           
            return retVal;
        }

        SqlCommand IEntity.InsertCommand(string tableName)
        {
            SqlCommand retVal = new SqlCommand();

            return retVal;
        }
    }
}