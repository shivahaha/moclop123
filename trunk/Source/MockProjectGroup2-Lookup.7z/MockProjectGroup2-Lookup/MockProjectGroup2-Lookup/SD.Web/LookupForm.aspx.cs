﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using SD.Business;
using SD.Entities;

namespace SD.Web
{
    public partial class _LookupForm : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

            btnSelect.Attributes.Add("onClick", "return rtAddress();");
            btnNone.Attributes.Add("onClick", "return none();");
            btnClose.Attributes.Add("onClick", "return pclose();");
            //HiddenField1.Value = "";
            HiddenField2.Value = string.Empty;

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            HiddenField1.Value = GridView1.SelectedRow.Cells[1].Text;
        }

        protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
        {
            //e.Row.Attributes.Add("onMouseOver", "this.style.background='#eeff00'");
            //e.Row.Attributes.Add("onMouseOut", "this.style.background='#ffffff'"); 

        }

        protected void GridViewRowSelector1_CheckedChanged(object sender, EventArgs e)
        {




        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            var dt = new DataTable();
            var mng = new LookupManager();
            dt = mng.Search(PostCodeBox.Text, TownBox.Text, StreetBox.Text);
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            PostCodeBox.Text = string.Empty;
            TownBox.Text = string.Empty;
            StreetBox.Text = string.Empty;
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {

        }

        protected void btnSelect_Click(object sender, EventArgs e)
        {
            //HiddenField1.Value = GridView1.SelectedRow.Cells[1].Text;    

        }

        protected void GridView1_PageIndexChanged(object sender, EventArgs e)
        {

        }

        protected void HiddenField1_ValueChanged(object sender, EventArgs e)
        {

        }

        protected void btnNone_Click(object sender, EventArgs e)
        {
            HiddenField1.Value = string.Empty;
        }

        protected void btnClose_Click1(object sender, EventArgs e)
        {

        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            var dt = new DataTable();
            var mng = new LookupManager();
            dt = mng.Search(PostCodeBox.Text, TownBox.Text, StreetBox.Text);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            GridView1.SelectedIndex = -1;
            HiddenField1.Value = string.Empty;
        }
    }
}
