﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Collections.Generic;
using SD.Business;

namespace SD.Web      
{
    public partial class _TypeOfBusinessLookUp : System.Web.UI.Page
    {
      
       
        protected void Page_Load(object sender, EventArgs e)
        {

            btnSelect.Attributes.Add("onClick", "return rtTOB();");
            btnNone.Attributes.Add("onClick", "return noneTOB();");
            btnClose.Attributes.Add("onClick", "return pcloseTOB();");
            //HiddenField1.Value = "";
            HiddenField2.Value = string.Empty;

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            HiddenField1.Value = GridView1.SelectedRow.Cells[1].Text;
        }

        protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
        {
            //e.Row.Attributes.Add("onMouseOver", "this.style.background='#eeff00'");
            //e.Row.Attributes.Add("onMouseOut", "this.style.background='#ffffff'"); 

        }

        protected void GridViewRowSelector1_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            var dt = new DataTable();
            var mng = new TypeOfBusinessLookupManager();
            dt = mng.Search(businessTxtBox.Text, sicTxtBox.Text);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void btnNone_Click(object sender, EventArgs e)
        {
            HiddenField1.Value = string.Empty;
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            businessTxtBox.Text = string.Empty;
            sicTxtBox.Text = string.Empty;
        }

        protected void btnSelect_Click(object sender, EventArgs e)
        {

        }

        protected void btnClose_Click(object sender, EventArgs e)
        {

        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            var dt = new DataTable();
            var mng = new TypeOfBusinessLookupManager();
            dt = mng.Search(businessTxtBox.Text, sicTxtBox.Text);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            GridView1.SelectedIndex = -1;
            HiddenField1.Value = string.Empty;
        }
    }
}
