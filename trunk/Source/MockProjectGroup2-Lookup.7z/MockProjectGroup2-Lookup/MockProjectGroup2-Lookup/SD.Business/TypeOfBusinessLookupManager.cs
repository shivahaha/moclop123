﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SD.DataAccess;

namespace SD.Business
{
    public class TypeOfBusinessLookupManager
    {
        public DataTable Search(string bname, string sic)
        {
            var a = new TypeOfBusinessDAO();
            var dt = new DataTable();
            dt.Columns.Add("Business Name");
            dt.Columns.Add("SIC Code");
            
            foreach (var adr in a.GetTypeOfBusiness(bname,sic))
            {
                dt.Rows.Add(adr.BusinessName, adr.SICCode);
            }
            return dt;


        }
    }
}
