﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SD.Entities;

namespace SD.DataAccess
{
    public class TypeOfBusinessDAO
    {
        public List<TypeOfBusiness> GetTypeOfBusiness(string bName,string sic)
        {
            
            var cnnString = @"Data Source=.\SQLEXPRESS;Initial Catalog=MockProject;UID=sa;PWD=12345678";
            var cn = new SqlConnection(cnnString);
            var cmdtext = @"SELECT BusinessName, SICCode FROM TypeOfBusiness
                                                         WHERE BusinessName LIKE '%' + @bname + '%'
                                                         AND   SICCode LIKE '%' + @sic + '%'
                                                             
                               ORDER BY BusinessName";

            var para1 = new SqlParameter("@bname", SqlDbType.NVarChar) { Value = bName };
            var para2 = new SqlParameter("@sic", SqlDbType.NVarChar) { Value = sic };
            


            var cmd = new SqlCommand(cmdtext);
            cmd.Parameters.Add(para1);
            cmd.Parameters.Add(para2);
           

            cmd.Connection = cn;
            cn.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            var list = new List<TypeOfBusiness>();
            while (sdr.Read())
            {
                list.Add(new TypeOfBusiness
                {
                    BusinessName = sdr[0].ToString(),
                    SICCode = sdr[1].ToString(),
                });

            }
            cmd.Dispose();
            cn.Close();
            cn.Dispose();
            return list;


        }
    }
}
