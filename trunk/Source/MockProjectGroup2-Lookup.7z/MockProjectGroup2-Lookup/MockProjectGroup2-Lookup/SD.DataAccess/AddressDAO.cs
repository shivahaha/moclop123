﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using SD.Entities;
namespace SD.DataAccess
{
    public class AddressDAO
    {
        public List<Address> GetAddress(string postcode, string town, string street)
        {
            
            var cnnString = @"Data Source=.\SQLEXPRESS;Initial Catalog=MockProject;UID=sa;PWD=12345678";
            var cn = new SqlConnection(cnnString);
            var cmdtext = @"SELECT Address, PostCode,TownName, CountyName, CountryName FROM Address A JOIN Country C ON A.CountryID = C.CountryID 
                                                             JOIN County C1 ON A.CountyID = C1.CountyID
                                                             JOIN Town T ON A.TownID = T.TownID 
                                                             WHERE PostCode LIKE '%'+@post+'%' 
                                                             AND TownName LIKE '%'+@town+'%'
                                                             AND Address LIKE '%'+@add+'%'
                                                             
                               ORDER BY Address";

            var para1 = new SqlParameter("@post", SqlDbType.NVarChar) {Value = postcode};
            var para2 = new SqlParameter("@town", SqlDbType.NVarChar) {Value = town};
            var para3 = new SqlParameter("@add", SqlDbType.NVarChar) { Value = street};

            
            var cmd = new SqlCommand(cmdtext);
            cmd.Parameters.Add(para1);
            cmd.Parameters.Add(para2);
            cmd.Parameters.Add(para3);
           
            cmd.Connection = cn;
            cn.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            var list = new List<Address>();
            while (sdr.Read())
            {
                list.Add(new Address
                             {
                                 address = sdr[0].ToString(),
                                 postcode = sdr[1].ToString(),
                                 town = sdr[2].ToString(),
                                 county = sdr[3].ToString(),
                                 country = sdr[4].ToString()
                             });
              
            }
            cmd.Dispose();
            cn.Close();
            cn.Dispose();
            return list;


        }
     
    }
}
