﻿using System;
using System.Collections.Generic;

namespace Bee
{
    public class Bee
    {
        protected Bee(string type, int healthLimit)
        {
            Type = type;
            Health = 100;
            HealthLimit = healthLimit;
        }

        public string Type { get; set; }

        public float Health { get; set; }

        protected int HealthLimit { get; set; }

        public bool Alive
        {
            get { return (Health > HealthLimit); }
        }

        public virtual void Damage(int damage)
        {
            if (Alive && damage > 0 && damage < 100)
            {
                Health -= damage;
            }
            if (Health < 0)
            {
                Health = 0;
            }
        }
    }

    public class Worker : Bee
    {
        public Worker() : base("Worker", 70)
        {
        }
    }

    public class Drone : Bee
    {
        public Drone() : base("Drone", 50)
        {
        }
    }

    public class Queen : Bee
    {
        public Queen() : base("Queen", 20)
        {
        }
    }

    internal class Program
    {
        private static void PrintBee(int number, Bee bee)
        {
            Console.WriteLine("{0} bee {1}, alive = {2}, health = {3}", bee.Type, number, bee.Alive, bee.Health);
        }

        private static void CreateNewBees(List<Bee> list)
        {
            list.Clear();
            for (int i = 0; i < 10; i++)
            {
                list.Add(new Worker());
                list.Add(new Drone());
                list.Add(new Queen());
            }
        }


        public static void Main(string[] args)
        {
            var list = new List<Bee>(30);

            CreateNewBees(list);

            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("---------------------------");
                Console.Write("Lua chon: \n1.Born\n" +
                              "2.Dame \n---\n");

                string resp = Console.ReadLine();
                switch (resp)
                {
                    case "1":
                        CreateNewBees(list);
                        for (int i = 0; i < list.Count; i++)
                        {
                            PrintBee(i + 1, list[i]);
                        }
                        break;
                    case "2":
                        var random = new Random();
                        for (int i = 0; i < list.Count; i++)
                        {
                            int damage = random.Next(0, 80);
                            list[i].Damage(damage);
                            PrintBee(i + 1, list[i]);
                        }
                        break;
                    case "q":
                    case "Q":
                    case "exit":
                    case "quit":
                        exit = true;
                        break;
                    default:
                        break;
                }
            }
        }
    }
}