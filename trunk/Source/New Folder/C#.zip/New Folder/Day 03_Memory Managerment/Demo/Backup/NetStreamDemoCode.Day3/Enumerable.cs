﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace NetStreamDemoCode.Day3
{
    public class EnumerableDemo
    {
        public  static  void Run()
        {

            var people = new People();
            people.Add("hai");
            people.Add("huy");
            people.Add("phonh");
            foreach (Person per in people)
            {
                Console.WriteLine( per.Name);
            }
        }

    }


    public  class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }

    }

    public class People : IEnumerator,IEnumerable
    {
        public  List<Person> Persons = new List<Person>();
        public int Pos = -1;
        public void Add ( string name)
        {
            Persons.Add(  new Person { Name = name});
        }
        public bool MoveNext()
        {

            Pos++;
            return (Pos < Persons.Count);
        }

        public void Reset()
        {
            Pos = -1;
        }
        object IEnumerator.Current
        {
            get { return Persons[Pos]; }
        }

       
        public IEnumerator GetEnumerator()
        {
            return this ;
        }
    }
}
