﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NetStreamDemoCode.Day3
{
    class CopyValueType
    {
        public  static  void  Run()
        {
            Dude due = new Dude();
            due.LeftShoe.Color = "RED";
            var due2 = due.CopyDude();
            due.LeftShoe.Color = "BLUE";
            Console.WriteLine(due.ToString());
            Console.WriteLine( due2.ToString());
            Console.ReadLine();
        }
    }

    public struct Shoe
    {
        public string Color;
    }
    public class Dude
    {
        public string Name;
        public Shoe RightShoe = new Shoe();
        public Shoe LeftShoe = new Shoe();
        public Dude CopyDude()
        {
            Dude newPerson = new Dude();
            newPerson.Name = Name;
            newPerson.LeftShoe = LeftShoe;
            newPerson.RightShoe = RightShoe;
            return newPerson;
        }
        public override string ToString()
        {
            return (Name + " : Dude!, I have a " + RightShoe.Color +
                " shoe on my right foot, and a " +
                 LeftShoe.Color + " on my left foot.");
        }

    }

}
