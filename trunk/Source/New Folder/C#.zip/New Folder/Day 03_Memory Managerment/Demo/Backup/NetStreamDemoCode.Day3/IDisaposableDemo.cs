﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace NetStreamDemoCode.Day3
{
    class IDisaposableDemo
    {

        public class  HeavyClass:IDisposable
        {
            public void Dispose()
            {
                throw new NotImplementedException();
            }
        }

        public  void    test()

        {
            

            using (  var myClass = new HeavyClass())
            {
                
            }





        }

        public  void getData()
        {
            System.Data.SqlClient.SqlConnection cn;
            using (cn = new SqlConnection())
            {
              
  

            }
          
            
        }

    }
}
