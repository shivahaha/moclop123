﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NetStreamDemoCode.Day3
{
    class PassReferenceTypeByRef
    {
        public  static  void Run()
        {
            var p = new PassReferenceTypeByRef();
            p.Go();

        }


        public void Go()
        {
            Thing x = new Animal();
            Switcharoo(ref x);
            Console.WriteLine(
                        "x is Animal    :   "
                        + (x is Animal).ToString());
            Console.WriteLine(
                        "x is Vegetable :   "
                        + (x is Vegetable).ToString());
        }

        public void Switcharoo(ref Thing pValue)
        {
            pValue = new Vegetable();
        }

    }

    public class Thing
    {
    }

    public class Animal : Thing
    {
        public int Weight;
    }

    public class Vegetable : Thing
    {
        public int Length;
    }


}
