﻿namespace NetStreamDemoCode.Day3
{
    internal class PassingReferenceType
    {
        public  static  void Run()
        {
            var result = ReturnValue2();
            System.Console.WriteLine( result);
        }

        public static  int ReturnValue2()
        {
            var x = new MyInt();
            x.MyValue = 3;

            var y = new MyInt();
            y = x;
            
            y.MyValue = 4;
            
            return x.MyValue;
        }
    }

    public class MyInt
    {
        public int MyValue;

      
    }
}