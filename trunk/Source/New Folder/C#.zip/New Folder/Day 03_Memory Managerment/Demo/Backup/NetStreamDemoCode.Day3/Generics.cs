﻿using System;
using System.Collections.Generic;

namespace NetStreamDemoCode.Day3
{
    public class GenericsDemo
    {
       
        public static  void  Run()
        {
            var   StackOfString = new Stack<string>();
            StackOfString.Push("Haipt");
            StackOfString.Push("Huydt");
            Console.WriteLine( StackOfString.Pop());
            Console.WriteLine(StackOfString.Pop());
            Console.WriteLine(StackOfString.Pop());
        }

    }

    
 
    public class Stack<T>
    {
        private readonly List<T> _items = new List<T>();

        public void Push(T item)
        {
            _items.Add(item);
        }

        public T Pop()
        {
        if (_items.Count==0) throw new Exception(" Stack is empty");
            var lastIndex = _items.Count - 1;
            T value = _items[lastIndex];
            _items.RemoveAt( lastIndex);
            return value;
        }
    }
}