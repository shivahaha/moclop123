﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace NetStreamDemoCode.Day3
{
    public  class HeavyClass:IDisposable
    {
        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
     
         
            CopyReferenceTypeSolution.Run();;
           
        }
    }
}
