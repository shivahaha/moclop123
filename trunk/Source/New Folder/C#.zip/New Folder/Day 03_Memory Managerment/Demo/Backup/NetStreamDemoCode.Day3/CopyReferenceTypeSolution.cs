﻿using System;

namespace NetStreamDemoCode.Day3
{
    internal class CopyReferenceTypeSolution
    {
        public static void Run()
        {
            

            var Bill = new Dude();
            Bill.Name = "Bill";
            Bill.LeftShoe = new Shoe();
            Bill.RightShoe = new Shoe();
            Bill.LeftShoe.Color = Bill.RightShoe.Color = "Blue";

            Dude Ted = Bill.CopyDude();
            Ted.Name = "Ted";

            Ted.LeftShoe.Color = "Red";
            Ted.RightShoe.Color = "Red";


            Console.WriteLine(Bill.ToString());
            Console.WriteLine(Ted.ToString());
            Console.ReadLine();
        }

        #region Nested type: Dude

        public class Dude
        {
            public Shoe LeftShoe;
            public string Name;
            public Shoe RightShoe;

            public Dude CopyDude()
            {
                var newPerson = new Dude();
                newPerson.Name = Name;
                newPerson.LeftShoe = LeftShoe.Clone() as Shoe;
                newPerson.RightShoe = RightShoe.Clone() as Shoe;
                return newPerson;
            }

            public override string ToString()
            {
                return (Name + " : Dude!, I have a " + RightShoe.Color +
                        " shoe on my right foot, and a " +
                        LeftShoe.Color + " on my left foot.");
            }
        }

        #endregion

        #region Nested type: Shoe

        public class Shoe : ICloneable
        {
            public string Color;

            #region ICloneable Members

            public object Clone()
            {

                var result = new Shoe();
                result.Color = Color.Clone() as string;
                return result;
            }

            #endregion
        }

        #endregion
    }
}