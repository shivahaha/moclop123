﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NetStreamDemoCode.Day3
{
    class CopyReferenceType
    {
        public  static  void  Run()
        {
             

            var Bill = new cDude();
            Bill.Name = "Bill";
            Bill.LeftShoe = new cShoe();
            Bill.RightShoe = new cShoe();
            Bill.LeftShoe.Color = Bill.RightShoe.Color = "Blue";

            cDude Ted = Bill.CopyDude();
            Ted.Name = "Ted";

            Ted.LeftShoe.Color = "Red";
            Ted.RightShoe.Color = "Red";

            Console.WriteLine(Bill.ToString());
            Console.WriteLine(Ted.ToString());
        }
    }

    public class cShoe
    {
        public string Color;
    }
    public class cDude
    {
        public string Name;
        public cShoe RightShoe;
        public cShoe LeftShoe;
        public cDude CopyDude()
        {
            cDude newPerson = new cDude();
            newPerson.Name = Name;
            newPerson.LeftShoe = LeftShoe;
            newPerson.RightShoe = RightShoe;
            return newPerson;
        }
        public override string ToString()
        {
            return (Name + " : Dude!, I have a " + RightShoe.Color +
                " shoe on my right foot, and a " +
                 LeftShoe.Color + " on my left foot.");
        }

    }

}
