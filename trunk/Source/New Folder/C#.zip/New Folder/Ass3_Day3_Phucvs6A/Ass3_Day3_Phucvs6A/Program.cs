﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ass3_Day3_Phucvs6A

{

    public class NhanVien

    {
        public string Name { get; set; }
        public string PhongBan { get; set; }
        public int NgayCong { get; set; }
        public float HesoLuong { get; set; }
        public float PhuCap { get; set; }
        public string ChucVu { get; set; }
        public float Luong;


       /* public NhanVien(string na,string pb,int nc,float hsl,float pc,string cv)
        {
            this.Name = "";
            this.NgayCong = 0;
            this.PhongBan = "";
            this.PhuCap = 0;
            this.ChucVu = "";
        }*/

        public NhanVien()
        {
            //throw new NotImplementedException();
        }

        public void Set (string na,string pb,int nc,float hsl,float pc,string cv)
       {
            this.Name = na;
            this.PhongBan = pb;
            this.NgayCong = nc;
            this.HesoLuong = hsl;
            this.PhuCap = pc;
            this.ChucVu = cv;
       }

        public void Input ()
        {
           
            
                Console.WriteLine("Enter Thong Tin Cua Nhan Vien\n");
                Console.Write("Enter name:");
                this.Name = Console.ReadLine();
                Console.Write("Enter chuc vu:1,2 or 3\n ");
                Console.WriteLine("\n1.Nhan Vien\n2.Pho Phong\n3.Truong Phong");
                this.ChucVu = Console.ReadLine();
                if (ChucVu == "1")
                {
                    this.PhuCap = 500;
                }
                if (ChucVu == "2")
                {
                    this.PhuCap = 500;
                }
                if (ChucVu == "3")
                {
                    this.PhuCap = 500;
                }
                Console.Write("Enter so ngay cong :");
                this.NgayCong = int.Parse(Console.ReadLine());
                Console.Write("Enter He so luong:");
                this.HesoLuong = float.Parse(Console.ReadLine());
                Console.Write("Enter Phong Ban :");
                this.PhongBan = Console.ReadLine();
                Console.WriteLine("\n----------------------------------------");
                //Console.WriteLine("Enter Phu Cap :");
               // this.PhuCap = int.Parse(Console.ReadLine())

            Luong = NgayCong*30 + PhuCap + HesoLuong*730;
        }
        public void Display()
        {
            
            Console.WriteLine("Ten : "+Name);
            Console.WriteLine("ChucVu: "+ChucVu);
            Console.WriteLine("SoNgayCong: " + NgayCong);
            Console.WriteLine("HeSoLuong: " + HesoLuong);
            Console.WriteLine("PhongBan: " + PhongBan);
            Console.WriteLine("PhuCap: " + PhuCap);
            Console.WriteLine("Luong : "+Luong+"  VND");

        }

    }
  





    class Program
    {
        static void Main(string[] args)
        {
            NhanVien nv = new NhanVien();
            nv.Input();
            nv.Display();
            Console.ReadLine();
        }
    }
}
