﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ass3
{
    class Program
    {
        static void Main(string[] args)
        {
            GiaoVien[] GiaoVienList = new GiaoVien[5];
            Employee[] employeeList = new Employee[5];
            int index = 0;
            int index1 = 0;

        Menu:
            Console.Clear();
            Console.WriteLine("1. Them Du Lieu Giao Vien");
            Console.WriteLine("2. Them Du Lieu Nhan Vien");
            Console.WriteLine("3. Tim Kiem Nhan Vien");
            Console.WriteLine("4. Hien thi danh sach");
            Console.WriteLine("0. Exit");
            Console.Write("Ban hay lua chon 1 so: ");
            string number = Console.ReadLine();
            switch (number)
            {
                case "1":
                    GiaoVien s = new GiaoVien();
                    Console.Write("Nhap Ten : ");
                    string name = Console.ReadLine();
                    s.SetName(name);
                    Console.Write("Nhap Khoa : ");
                    string khoa = Console.ReadLine();
                    s.Setkhoa(khoa);
                    Console.Write("Nhap Trinh Do: ");
                    Console.WriteLine("\n1.CuNhan\n2.ThacSi\n3.TienSi");
                    string trinhdo = Console.ReadLine();
                    s.Settrinhdo(trinhdo);
                    if (trinhdo == "1")
                    {
                        s.Setphucap(300);
                    }
                    if (trinhdo == "2")
                    {
                        s.Setphucap(500);
                    }
                    if (trinhdo == "3")
                    {
                        s.Setphucap(1000);
                    }
                    //Console.Write("Nhap Phu Cap : ");
                   // int phucap = int.Parse(Console.ReadLine());
                   // s.Setphucap(phucap);
                    Console.Write("Nhap So Tiet Day : ");
                    int sotietday = int.Parse(Console.ReadLine());
                    s.Setsotietday(sotietday);
                    Console.Write("Nhap He So Luong : ");
                    int hesoluong = int.Parse(Console.ReadLine());
                    s.Sethesoluong(hesoluong);
                    GiaoVienList[index] = s;
                    index++;
                    goto Menu;

                case "2":
                    Employee s1 = new Employee();
                    Console.Write("Nhap Ten : ");
                    string name1 = Console.ReadLine();
                    s1.SetName1(name1);
                    Console.Write("Nhap Phong Ban : ");
                    string pb1 = Console.ReadLine();
                    s1.Setphongban(pb1);
                    Console.Write("So Ngay Cong : ");
                    int snc = int.Parse(Console.ReadLine());
                    s1.Setsongaycong(snc);
                    Console.Write("Nhap He So Luong : ");
                    int hesoluong1 = int.Parse(Console.ReadLine());
                    s1.Sethesoluong1(hesoluong1);
                    //Console.Write("Nhap Phu Cap : ");
                   // int phucap1 = int.Parse(Console.ReadLine());
                   // s1.Setphucap1(phucap1);
                    Console.Write("Nhap Chuc Vu: ");
                    string cv1 = Console.ReadLine();
                    s1.Setchucvu(cv1);
                    Console.WriteLine("\n1.Nhan Vien\n2.Pho Phong\n3.Truong Phong");
                    if (cv1 == "1")
                    {
                        s1.Setphucap1(500);
                    }
                    if (cv1 == "2")
                    {
                        s1.Setphucap1(1000);
                    }
                    if (cv1 == "3")
                    {
                        s1.Setphucap1(2000);
                    }
                    float luong1 = hesoluong1*730 +snc*30;
                    s1.SetLuong(luong1);
                    employeeList[index1] = s1;
                    index1++;
                    goto Menu;
                case "3":
                    Console.Write("Ten :");
                    string tk = Console.ReadLine();
                    Console.Write("Phong Ban :");
                    string pb = Console.ReadLine();
                    foreach (Employee s2 in employeeList)
                    {
                        if (s2.name1 == tk && s2.phongban == pb)
                        {
                            s2.Display();
                            break;
                        }
                        else
                        {
                            Console.WriteLine("khong tim thay du lieu phu hop");

                            break;
                        }
                    }
                    Console.ReadLine();
                    goto Menu;
                case "4":
                    Console.WriteLine("Danh Sach Can bo cong nhan vien\n---------------------\n");
                    foreach (GiaoVien s3 in GiaoVienList)
                    {
                        if (s3 != null)
                        {
                            s3.Display();
                        }
                    }
                    foreach (Employee s4 in employeeList)
                    {
                        if (s4 != null)
                        {
                            s4.Display();
                        }
                    }
                    Console.ReadLine();
                    goto Menu;
                case "0":
                    break;
                default:
                    Console.WriteLine("Nhap sai so, chi nhan cac gia tri tu 1-4");
                    Console.ReadLine();
                    goto Menu;

            }
        }
    }

    public class GiaoVien
    {
        public string name;
        public string khoa;
        string trinhdo;
        int phucap;
        int sotietday;
        int hesoluong;
        public float luong;

        public void SetLuong(float luong)
        {
            this.luong = luong;
        }

        public void SetName(string name)
        {
            this.name = name;
        }

        public void Setkhoa(string add)
        {
            khoa = add;
        }
        public void Settrinhdo(string td)
        {
            trinhdo = td;
        }
        public void Setphucap(int pc)
        {
            phucap = pc;
        }
        public void Setsotietday(int std)
        {
            sotietday = std;
        }
        public void Sethesoluong(int hsl)
        {
            hesoluong = hsl;
        }


        public void Display()
        {
            Console.WriteLine("GiangVien");
            Console.WriteLine("=================");
            Console.WriteLine("Ten: {0}", name);
            Console.WriteLine("Khoa: {0}", khoa);
            Console.WriteLine("Trinh Do: {0}", trinhdo);
            Console.WriteLine("Phu Cap: {0}", phucap);
            Console.WriteLine("So Tiet Day: {0}", sotietday);
            Console.WriteLine("He So Luong: {0}", hesoluong);
            Console.WriteLine("\n--------------------------\n");


        }
    }
}
public class Employee
{

    public string name1;
    public string phongban;
    int songaycong;
    int hesoluong1;
    public int phucap1;
    public string chucvu;
    public float luong1;

    public void SetLuong(float luong1)
    {
        this.luong1 = luong1;
    }

    public void SetName1(string name1)
    {
        this.name1 = name1;
    }
    public void Setphongban(string pb1)
    {
        phongban = pb1;
    }
    public void Setsongaycong(int snc)
    {
        songaycong = snc;
    }
    public void Sethesoluong1(int hsl1)
    {
        hesoluong1 = hsl1;
    }
    public void Setphucap1(int pc1)
    {
        phucap1 = pc1;
    }
    public void Setchucvu(string cv1)
    {
        chucvu = cv1;
    }


    public void Display()
    {

        Console.WriteLine("Nhan Vien");
        Console.WriteLine("=================");
        Console.WriteLine("Ten: {0}", name1);
        Console.WriteLine("Phong Ban: {0}", phongban);
        Console.WriteLine("So Ngay Cong: {0}", songaycong);
        Console.WriteLine("He So Luong: {0}", hesoluong1);
        Console.WriteLine("Phu Cap: {0}", phucap1);
        Console.WriteLine("Chuc Vu: {0}", chucvu);
        Console.WriteLine("\n--------------------------\n");

    }
}




