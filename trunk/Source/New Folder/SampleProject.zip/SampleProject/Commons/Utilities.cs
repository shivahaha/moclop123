﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SampleProject.Entity;
using System.Data;

namespace SampleProject.Commons
{
    public class Utilities
    {
    }
}