﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SampleProject.Biz;

namespace SampleProject.UserControls.Users
{
    public partial class Details : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //UserBiz 
        }
    }
}