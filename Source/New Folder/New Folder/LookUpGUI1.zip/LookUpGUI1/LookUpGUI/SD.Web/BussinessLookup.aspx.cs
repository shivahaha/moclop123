﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using LookUpGUI.SD.DataAccess;
namespace LookUpGUI.SD.Web
{
    public partial class BussinessLookUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            BtnSelect.Attributes.Add("onClick", "return rtTOB();");
            BtnNone.Attributes.Add("onClick", "return noneTOB();");
            BtnClose.Attributes.Add("onClick", "return pcloseTOB();");
            //HiddenField1.Value = "";
            HiddenField2.Value = string.Empty;
        }

       

        protected void GVBussiness_PageIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GVBussiness_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVBussiness.PageIndex = e.NewPageIndex;

            string a1 = txtBussiness.Text;
            string a2 = txtSic.Text;
            LookUpDAO dao = new LookUpDAO();
            DataTable dt = dao.GetRecord(a1, a2);
            GVBussiness.DataSource = dt;
            GVBussiness.DataBind();
            GVBussiness.SelectedIndex = -1;
            HiddenField1.Value = string.Empty;
        }

        protected void GVBussiness_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GVBussiness_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {

        }
        //empty textbox
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void BtnClear_Click1(object sender, EventArgs e)
        {
            txtSic.Text = string.Empty;
            txtBussiness.Text = string.Empty;
        }
        //get data to gridview
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void BtnSearch_Click(object sender, EventArgs e)
        {

            string a1 = txtBussiness.Text;
            string a2 = txtSic.Text;
            LookUpDAO dao = new LookUpDAO();
            DataTable dt = dao.GetRecord(a1, a2);
            GVBussiness.DataSource = dt;
            GVBussiness.DataBind();
        }

        protected void HiddenField1_ValueChanged(object sender, EventArgs e)
        {

        }

       
    }
}
