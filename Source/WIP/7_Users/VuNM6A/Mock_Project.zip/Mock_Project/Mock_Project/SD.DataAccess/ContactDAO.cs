﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Mock_Project.SD.DataAccess
{
    public class ContactDAO
    {
        public static string ConnectString = @"Data Source=TRN-LAB2-PC01\SQLEXPRESS;Initial Catalog=absd;Persist Security Info=True;User ID=SA;Password=12345678";

        public void AddContact(string firstName, string surname, string knownAs, string officePhone, 
            string mobilePhone, string stHomePhone, string email, string managerName, 
            string contactType, string contactMethod, string jobRole, string workbase, 
            string jobTitlte, string active)
        {
            SqlConnection sqlConnection1 = new SqlConnection(ConnectString);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText =
                string.Format("INSERT INTO Contact(FirstName, Surname, KnownAs, OfficePhone, MobilePhone, STHomePhone, Email, ManagerName, ContactType, ContactMethod, JobRole, Workbase, Jobtitle, Active) " + "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}')", firstName, surname, knownAs, officePhone, mobilePhone, stHomePhone, email, managerName, contactType, contactMethod, jobRole, workbase, jobTitlte, active);
            cmd.Connection = sqlConnection1;
            sqlConnection1.Open();
            cmd.ExecuteNonQuery();
            sqlConnection1.Close();
        }

        public void ListContact(string query, GridView gridView)
        {
            var sqlConnection1 = new SqlConnection(ConnectString);
            SqlCommand cmd = new SqlCommand(query, sqlConnection1);
            DataTable data = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(data);
            gridView.DataSource = data;
            gridView.DataBind();
        }
    }
}