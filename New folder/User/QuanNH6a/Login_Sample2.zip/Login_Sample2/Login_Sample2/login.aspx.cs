﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

namespace Login_Sample2
{
    public partial class login : System.Web.UI.Page 
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                       
        }
    
        void SiteSpecificUserLoggingMethod(string UserName, string Password)
        {
            try
            {
                SqlConnection UGIcon = new SqlConnection();
                UGIcon.ConnectionString = @"Data Source=TRN-LAB2-PC003\SQLEXPRESS;User ID=sa;Password=12345678";
                UGIcon.Open();

                string userText = Login1.UserName.ToString();
                string passText = Login1.Password.ToString();

                SqlCommand cmd = new SqlCommand("SELECT ISNULL(Account, '') AS Account, ISNULL(Password,'') AS Password, ISNULL(Role,'') AS Role FROM User WHERE Account='" + userText + "' and Password='" + passText + "'", UGIcon);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    cmd = new System.Data.SqlClient.SqlCommand("SELECT Role from User where Account=@Account", UGIcon);
                    cmd.Parameters.AddWithValue("Account", userText);
                    string role = cmd.ExecuteScalar().ToString();
                    UGIcon.Close();
                }
            }
            catch (Exception ex) {  }
        }


        protected void Login_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                Users users = new Users();
                bool auth;
                auth = users.AuthenticateUser(Login1.UserName.ToString(), Login1.Password.ToString());

                if (auth)
                {
                    // authenticated was successful, lets create the authentication cookie and redirect them to another place (either where they were trying to go to or default.aspx)
                    FormsAuthentication.RedirectFromLoginPage(Login1.UserName.ToString(), false);
                }
            }
            else
            {
                Login1.FailureText += " Missing some fields. Please try again.";
            }
        }
    }

    public class Users
    {
        public bool AuthenticateUser(string username, string password)
        {
            bool authenticated;
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=TRN-LAB2-PC003\SQLEXPRESS;User ID=sa;Password=12345678";
            conn.Open();

           /* SqlCommand cmd = new SqlCommand("AuthenticateUser", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@password", password);
            conn.Open();
            */
            SqlCommand cmd = new SqlCommand("SELECT ISNULL(Account, '') AS Account, ISNULL(Password,'') AS Password FROM [User] WHERE Account='" + username + "' and Password='" + password + "'", conn);
            
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                authenticated = true;
            }
            else
            {
                authenticated = false;
            }

            reader.Close();
            conn.Close();
            conn.Dispose();

            return authenticated;
        }
    }
}
