﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using PhucVS6A_Team1.Commons;
namespace PhucVS6A_Team1.Entity
{
    public class OrganizationEntity : IEntity
    {
        public string OrganizationName { get; set; }
        public string ShortDescription { get; set; }
        public int AddressId { get; set; }
        public int BusinessId { get; set; }
        public string PhoneNumber { get; set; }
        public string CityTown { get; set; }
        public string County { get; set; }
        public int CountryId { get; set; }
        public string PreferredOrganization { get; set; }
        public int ContactId { get; set; }
        public string Fax { get; set; }
        public string Email { get; set; }
        public string WebAddress { get; set; }
        public string CharityNumber { get; set; }
        public string CompanyNumber { get; set; }
        public string OrganizationSpecialism { get; set; }
        public string ServiceDisabilities { get; set; }
        public string ServiceBarriers { get; set; }
        public string ServiceBenefits { get; set; }
        public string ServiceCircumstances { get; set; }
        public string ServiceEthnicity { get; set; }
        public string Accreditation { get; set; }
        public bool IsActive { get; set; }

        public int OrganizationId
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        void IEntity.Mapping(System.Data.DataRow row)
        {
            OrganizationName = (row[Constants.Organizations.SqlColumn.OrganizationName] == null || row[Constants.Organizations.SqlColumn.OrganizationName] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.OrganizationName].ToString();
            ShortDescription = (row[Constants.Organizations.SqlColumn.ShortDescription] == null || row[Constants.Organizations.SqlColumn.ShortDescription] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.ShortDescription].ToString();
            AddressId = (row[Constants.Organizations.SqlColumn.AddressId] == null || row[Constants.Organizations.SqlColumn.AddressId] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.AddressId].ToString();
            BusinessId = (row[Constants.Organizations.SqlColumn.BusinessId] == null || row[Constants.Organizations.SqlColumn.BusinessId] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.BusinessId].ToString();
            PhoneNumber = (row[Constants.Organizations.SqlColumn.PhoneNumber] == null || row[Constants.Organizations.SqlColumn.PhoneNumber] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.PhoneNumber].ToString();
            CityTown = (row[Constants.Organizations.SqlColumn.CityTown] == null || row[Constants.Organizations.SqlColumn.CityTown] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.CityTown].ToString();
            County = (row[Constants.Organizations.SqlColumn.County] == null || row[Constants.Organizations.SqlColumn.County] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.County].ToString();
            PreferredOrganization = (row[Constants.Organizations.SqlColumn.PreferredOrganization] == null || row[Constants.Organizations.SqlColumn.PreferredOrganization] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.PreferredOrganization].ToString();
            ContactId = (row[Constants.Organizations.SqlColumn.ContactId] == null || row[Constants.Organizations.SqlColumn.ContactId] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.ContactId].ToString();
            Fax = (row[Constants.Organizations.SqlColumn.Fax] == null || row[Constants.Organizations.SqlColumn.Fax] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.Fax].ToString();
            Email = (row[Constants.Organizations.SqlColumn.Email] == null || row[Constants.Organizations.SqlColumn.Email] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.Email].ToString();
            WebAddress = (row[Constants.Organizations.SqlColumn.WebAddress] == null || row[Constants.Organizations.SqlColumn.WebAddress] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.WebAddress].ToString();
            CharityNumber = (row[Constants.Organizations.SqlColumn.CharityNumber] == null || row[Constants.Organizations.SqlColumn.CharityNumber] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.CharityNumber].ToString();
            CompanyNumber = (row[Constants.Organizations.SqlColumn.CompanyNumber] == null || row[Constants.Organizations.SqlColumn.CompanyNumber] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.CompanyNumber].ToString();
            OrganizationSpecialism = (row[Constants.Organizations.SqlColumn.OrganizationSpecialism] == null || row[Constants.Organizations.SqlColumn.OrganizationSpecialism] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.OrganizationSpecialism].ToString();
            ServiceDisabilities = (row[Constants.Organizations.SqlColumn.ServiceDisabilities] == null || row[Constants.Organizations.SqlColumn.ServiceDisabilities] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.ServiceDisabilities].ToString();
            ServiceBarriers = (row[Constants.Organizations.SqlColumn.ServiceBarriers] == null || row[Constants.Organizations.SqlColumn.ServiceBarriers] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.ServiceBarriers].ToString();
            ServiceBenefits = (row[Constants.Organizations.SqlColumn.ServiceBenefits] == null || row[Constants.Organizations.SqlColumn.ServiceBenefits] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.ServiceBenefits].ToString();
            ServiceCircumstances = (row[Constants.Organizations.SqlColumn.ServiceCircumstances] == null || row[Constants.Organizations.SqlColumn.ServiceCircumstances] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.ServiceCircumstances].ToString();
            ServiceEthnicity = (row[Constants.Organizations.SqlColumn.ServiceEthnicity] == null || row[Constants.Organizations.SqlColumn.ServiceEthnicity] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.ServiceEthnicity].ToString();
            Accreditation = (row[Constants.Organizations.SqlColumn.Accreditation] == null || row[Constants.Organizations.SqlColumn.FaxAccreditation] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.FaxAccreditation].ToString();
            IsActive = (row[Constants.Organizations.SqlColumn.IsActive] == null || row[Constants.Organizations.SqlColumn.IsActive] is DBNull) ? string.Empty : row[Constants.Organizations.SqlColumn.IsActive].ToString();

        }


    }
}
