﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using PhucVS6A_Team1.Commons;
namespace PhucVS6A_Team1.Entity
{
    public class ProgrammeEntity : IEntity
    {
        public int ProgramId { get; set; }
        public string ProgramName { get; set; }
        public string Description { get; set; }
        public int ContactId { get; set; }
        public bool IsActive { get; set; }
        public int ProgramId
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }
        void IEntity.Mapping(System.Data.DataRow row)
        {
            ProgramName = (row[Constants.Programs.SqlColumn.ProgramName] == null || row[Constants.Programs.SqlColumn.ProgramName] is DBNull) ? string.Empty : row[Constants.Programs.SqlColumn.ProgramName].ToString();
            Description = (row[Constants.Programs.SqlColumn.Description] == null || row[Constants.Programs.SqlColumn.Description] is DBNull) ? string.Empty : row[Constants.Programs.SqlColumn.Description].ToString();
            ContactId = (row[Constants.Programs.SqlColumn.ContactId] == null || row[Constants.Programs.SqlColumn.ContactId] is DBNull) ? string.Empty : row[Constants.Programs.SqlColumn.ContactId].ToString();
            IsActive = (row[Constants.Programs.SqlColumn.IsActive] == null || row[Constants.Programs.SqlColumn.IsActive] is DBNull) ? string.Empty : row[Constants.Programs.SqlColumn.IsActive].ToString();

        }
    }
}
