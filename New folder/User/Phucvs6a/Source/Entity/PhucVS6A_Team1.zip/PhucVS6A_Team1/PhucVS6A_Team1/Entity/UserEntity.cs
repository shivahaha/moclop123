﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using PhucVS6A_Team1.Commons;

namespace PhucVS6A_Team1.Entity
{
    public class UserEntity : IEntity
    {

        public string Account { get; set; }
        public string Password { get; set; }
        public int RoleId { get; set; }
        public string Email { get; set; }
        public bool IsActive {get; set;}


        public int UserId
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }
        void IEntity.Mapping(System.Data.DataRow row)
        {
            Account = (row[Constants.Users.SqlColumn.Account] == null || row[Constants.Users.SqlColumn.Account] is DBNull) ? string.Empty : row[Constants.Users.SqlColumn.Account].ToString();
            Password = (row[Constants.Users.SqlColumn.Password] == null || row[Constants.Users.SqlColumn.Password] is DBNull) ? string.Empty : row[Constants.Users.SqlColumn.Password].ToString();
            RoleId = (row[Constants.Users.SqlColumn.RoleId] == null || row[Constants.Users.SqlColumn.RoleId] is DBNull) ? string.Empty : row[Constants.Users.SqlColumn.RoleId].ToString();
            Email = (row[Constants.Users.SqlColumn.Email] == null || row[Constants.Users.SqlColumn.Email] is DBNull) ? string.Empty : row[Constants.Users.SqlColumn.Email].ToString();
            IsActive = (row[Constants.Users.SqlColumn.IsActive] == null || row[Constants.Users.SqlColumn.IsActive] is DBNull) ? string.Empty : row[Constants.Users.SqlColumn.IsActive].ToString();

        }
    }
}
